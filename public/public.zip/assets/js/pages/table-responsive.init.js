/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!*****************************************************!*\
  !*** ./resources/js/pages/table-responsive.init.js ***!
  \*****************************************************/
$(function () {
  $(".table-responsive").responsiveTable({
    addDisplayAllBtn: "btn btn-secondary"
  }), $(".btn-toolbar [data-toggle=dropdown]").attr("data-bs-toggle", "dropdown");
});
/******/ })()
;