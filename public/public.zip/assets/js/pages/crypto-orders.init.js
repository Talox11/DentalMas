/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************************************!*\
  !*** ./resources/js/pages/crypto-orders.init.js ***!
  \**************************************************/
$(".select2-search-disable").select2({
  minimumResultsForSearch: 1 / 0
}), $(document).ready(function () {
  $(".datatable").DataTable(), $(".dataTables_length select").addClass("form-select form-select-sm");
});
/******/ })()
;